# Bundle lifecycle logs

Period covered: 2026-10-20 to 2026-10-29 (UTC).

## Client

A Rust client submits single-transaction swap bundles to the Jito block engine
(gRPC `SendBundle` with an authenticated searcher identity, Frankfurt block engine). For each bundle it:

1. calculates route and swap instruction,
2. builds a v0 transaction with a fresh blockhash and a tip transfer to a Jito tip account,
3. submits it as a bundle and logs the returned bundle id,
4. receives block-engine results for the bundle on the SubscribeBundleResults stream,
5. checks the transaction on-chain over RPC (confirmed commitment) and logs the landing slot plus a
   cost breakdown: base fee, priority fee, tip, and the swap's net SOL result.

The client also logs a cumulative `FUNNEL` line every 10 minutes.

## Files

- `summary.csv` and `funnel.md`: per day and run: counts and land rate.
- `traces/bundles.log`: the full lifecycle of sample bundles, from tx build and submission
  through block-engine events to the on-chain result. Covers landed and not-landed examples.
- `onchain_verification.csv`: on-chain status of every traced signature at export time, with an explorer link.
- `logs/<run>.log.gz`: the full log of the latest run. Earlier runs keep bundle-related lines only.
  API keys and proxy credentials are redacted.

## Count definitions

| column | meaning |
|---|---|
| submitted | `SendBundle` returned a bundle id |
| simulated | unique bundles with a block-engine result that implies simulation ran: ACCEPTED, REJECTED simulation_failure, or REJECTED auction bid |
| sim_failed | REJECTED simulation_failure |
| auction_rejected | REJECTED state_auction_bid or winning_batch_bid |
| forwarded | ACCEPTED: forwarded to a Jito-Solana leader (one event per leader, counted once per bundle) |
| be_processed / be_finalized / be_dropped_after_forward | PROCESSED / FINALIZED / DROPPED events |
| landed_onchain | the transaction was found on-chain at confirmed commitment |
| not_landed | not found on-chain within the 8s check window |

## Notes

- Block-engine counts come from the result stream. It does not send an event for every bundle,
  including some that landed, so treat simulated and forwarded as lower bounds. In our runs the
  stream has sent ACCEPTED and REJECTED events but no PROCESSED or FINALIZED events, so
  `landed_onchain` comes from our own RPC check.
- `not_landed` uses an 8s window. A bundle that lands later is counted as not landed;
  `onchain_verification.csv` gives the final status for traced bundles.
